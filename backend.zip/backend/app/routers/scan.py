import json
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

router    = APIRouter(prefix="/scan", tags=["Scan"])
templates = Jinja2Templates(directory="app/templates")

# ── SCAN PAGE ─────────────────────────────────────────────────────────────────

@router.get("/", response_class=HTMLResponse)
def scan_page(request: Request):
    return templates.TemplateResponse(
        request=request, name="scan/index.html", context={}
    )

# ── EXTRACT — receives image, calls Gemini Vision, returns structured JSON ────

@router.post("/extract")
async def extract_bill(request: Request):
    data = await request.json()

    image_b64  = data.get("image")
    media_type = data.get("media_type", "image/jpeg")

    if not image_b64:
        return JSONResponse(
            status_code=400,
            content={"success": False, "error": "No image provided"}
        )

    prompt = """You are reading a jewellery shop bill or invoice from India.
Extract every field you can read and return ONLY a valid JSON object — no explanation, no markdown, no code fences.

Return this exact structure (use null for fields you cannot read):
{
  "invoice_date": "YYYY-MM-DD or null",
  "invoice_type": "sale or purchase (guess from context, default sale)",
  "party_name": "customer or supplier name or null",
  "party_phone": "phone number digits only or null",
  "party_address": "address or null",
  "party_gstin": "GSTIN if visible or null",
  "payment_mode": "cash or upi or card or cheque or null",
  "items": [
    {
      "item_name": "description of item",
      "purity": "22K or 18K etc or null",
      "weight_grams": number or null,
      "rate_per_gram": number or null,
      "making_charges": number or null,
      "hsn_code": "7113 or whatever is shown or null",
      "amount": number or null
    }
  ],
  "old_gold_value": number or null,
  "discount": number or null,
  "grand_total": number or null,
  "amount_paid": number or null,
  "notes": "any extra text worth noting or null"
}

Rules:
- items array must always exist, even if empty []
- All number fields must be actual numbers (not strings)
- Dates must be YYYY-MM-DD format
- If you see "22 carat" write "22K" for purity
- HSN code 7113 is standard for gold jewellery
- Do not invent data — only extract what is clearly visible
- Return ONLY the JSON, nothing else"""

    raw = ""
    try:
        import base64
        from google import genai
        from google.genai import types

        # Client reads GOOGLE_API_KEY from environment automatically
        client = genai.Client()

        # Decode base64 string back to raw bytes for Gemini
        image_bytes = base64.b64decode(image_b64)

        response = client.models.generate_content(
            model    = "gemini-2.0-flash",
            contents = [
                types.Part.from_bytes(
                    data      = image_bytes,
                    mime_type = media_type,
                ),
                prompt,
            ],
        )

        raw = response.text.strip()

        # Strip any accidental markdown fences
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        raw = raw.strip()

        extracted = json.loads(raw)
        return {"success": True, "data": extracted}

    except json.JSONDecodeError as e:
        return JSONResponse(
            status_code=422,
            content={
                "success": False,
                "error":   f"Could not parse Gemini response as JSON: {str(e)}",
                "raw":     raw,
            }
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"success": False, "error": str(e)}
        )